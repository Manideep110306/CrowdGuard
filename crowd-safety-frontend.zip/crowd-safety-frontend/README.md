# AI Crowd Safety – Frontend (React + Vite + Tailwind v4 + Chart.js)

    npm install
    npm run dev

Runs with sample data by default (`VITE_USE_MOCK=true`). Login: any email/password.

## Connect to Flask
1. Set `VITE_USE_MOCK=false` in `.env`; Flask must run on `localhost:5000` (proxy in `vite.config.js`), with CORS if hosted separately.
2. Live video: expose an MJPEG route (e.g. `/video_feed`) and set `VITE_STREAM_URL`.
3. All requests live in `src/services/api.js` – one function per endpoint:
   `/login /logout /cameras /monitoring/start|stop|status /zones /alerts/{id}/acknowledge|resolve /analytics /ai-assistant`
   Extra endpoints this UI also calls (add them in Flask): `POST /api/reports`, `GET|PUT /api/settings`, `POST /api/cameras/test`.
4. Expected JSON shapes = the objects in `src/data/mock.js`. MongoDB `_id` should be returned as `id`.
   Zones need `people_count` (live count); occupancy is calculated in the UI.
