// Sample data. Shapes mirror the MongoDB documents returned by Flask (id = stringified _id).
export const admin = { name: 'Admin Operator', email: 'admin@crowdsafety.local', role: 'Administrator' };

export const cameras = [
  { id: 'cam1', name: 'Testing Webcam', source_type: 'Webcam', source: '0', location: 'Testing Room', status: 'ONLINE', last_active: 'Now' },
  { id: 'cam2', name: 'Future CCTV Camera 1', source_type: 'CCTV', source: 'rtsp://192.168.1.20:554/stream', location: 'Main Gate', status: 'OFFLINE', last_active: '2 days ago' },
  { id: 'cam3', name: 'Sample Video', source_type: 'Video', source: 'videos/crowd.mp4', location: 'Test Footage', status: 'OFFLINE', last_active: '1 day ago' },
];

export const zones = [
  { id: 'z1', camera_id: 'cam1', name: 'Zone A', capacity: 20, warning_threshold: 80, critical_threshold: 100, enabled: true, people_count: 5 },
  { id: 'z2', camera_id: 'cam1', name: 'Zone B', capacity: 15, warning_threshold: 80, critical_threshold: 100, enabled: true, people_count: 12 },
  { id: 'z3', camera_id: 'cam1', name: 'Zone C', capacity: 10, warning_threshold: 80, critical_threshold: 100, enabled: true, people_count: 16 },
];

export const alerts = [
  { id: 'ALT-1042', severity: 'CRITICAL', camera: 'Testing Camera', zone: 'Zone C', people_count: 16, capacity: 10, occupancy: 160, created_at: '10:42 PM', status: 'ACTIVE',
    history: ['10:42 PM – Alert created (occupancy crossed 100%)', '10:41 PM – Zone C entered WARNING (85%)'] },
  { id: 'ALT-1041', severity: 'WARNING', camera: 'Testing Camera', zone: 'Zone B', people_count: 13, capacity: 15, occupancy: 85, created_at: '10:38 PM', status: 'RESOLVED',
    history: ['10:38 PM – Alert created (85%)', '10:40 PM – Resolved by Admin'] },
  { id: 'ALT-1040', severity: 'WARNING', camera: 'Testing Camera', zone: 'Zone C', people_count: 9, capacity: 10, occupancy: 90, created_at: '10:21 PM', status: 'ACKNOWLEDGED',
    history: ['10:21 PM – Alert created (90%)', '10:23 PM – Acknowledged by Admin'] },
  { id: 'ALT-1039', severity: 'CRITICAL', camera: 'Testing Camera', zone: 'Zone A', people_count: 21, capacity: 20, occupancy: 105, created_at: '09:55 PM', status: 'RESOLVED',
    history: ['09:55 PM – Alert created (105%)', '09:58 PM – Resolved by Admin'] },
];

export const status = { running: true, fps: 24, camera_id: 'cam1', ai_engine: 'ONLINE', database: 'CONNECTED', backend: 'ONLINE' };

export const analytics = {
  labels: ['6 PM', '7 PM', '8 PM', '9 PM', '10 PM', '11 PM'],
  people: [8, 14, 22, 30, 33, 21],
  zone_occupancy: { 'Zone A': [20, 35, 60, 90, 25, 20], 'Zone B': [30, 45, 70, 82, 80, 50], 'Zone C': [40, 70, 110, 150, 160, 90] },
  alerts: [0, 1, 3, 4, 5, 2],
  camera_activity: { 'Testing Webcam': 92, 'Future CCTV Camera 1': 0, 'Sample Video': 8 },
  stats: { average_occupancy: '71%', peak_occupancy: '160%', total_alerts: 15, critical_alerts: 6, peak_time: '10:00 PM' },
};

export const insights = [
  'Zone C has remained above 100% capacity for 8 seconds. Immediate monitoring is recommended.',
  'Zone B occupancy has increased by 35% in the last 5 minutes.',
  'Peak crowd activity detected near Camera 02.',
  'Three warning events occurred in the last hour.',
];
