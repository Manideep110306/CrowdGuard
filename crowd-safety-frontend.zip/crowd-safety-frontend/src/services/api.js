// Single place for all backend calls. Set VITE_USE_MOCK=false to talk to Flask.
import * as m from '../data/mock';

const BASE = import.meta.env.VITE_API_URL || '/api';
const MOCK = import.meta.env.VITE_USE_MOCK !== 'false';
export const STREAM_URL = import.meta.env.VITE_STREAM_URL || '';

const fake = (data) => new Promise((r) => setTimeout(() => r(JSON.parse(JSON.stringify(data))), 150));

async function request(path, method = 'GET', body) {
  const res = await fetch(BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token') || ''}` },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).message || `Request failed (${res.status})`);
  return res.json();
}
const call = (mock, path, method, body) => (MOCK ? fake(mock) : request(path, method, body));

export const api = {
  // Authentication
  login: (creds) => call({ token: 'demo-token', user: m.admin }, '/login', 'POST', creds),
  logout: () => call({ ok: true }, '/logout', 'POST'),
  // Cameras
  getCameras: () => call(m.cameras, '/cameras'),
  addCamera: (c) => call({ ...c, id: String(Date.now()), status: 'OFFLINE', last_active: '—' }, '/cameras', 'POST', c),
  updateCamera: (id, c) => call(c, `/cameras/${id}`, 'PUT', c),
  deleteCamera: (id) => call({ ok: true }, `/cameras/${id}`, 'DELETE'),
  testCamera: (c) => call({ ok: true, message: 'Connection successful' }, '/cameras/test', 'POST', c),
  // Monitoring
  startMonitoring: (camera_id) => call({ running: true }, '/monitoring/start', 'POST', { camera_id }),
  stopMonitoring: () => call({ running: false }, '/monitoring/stop', 'POST'),
  getMonitoringStatus: () => call(m.status, '/monitoring/status'),
  // Zones
  getZones: (camera_id) => call(m.zones, `/zones?camera_id=${camera_id || ''}`),
  saveZone: (z) => call(z, z.id ? `/zones/${z.id}` : '/zones', z.id ? 'PUT' : 'POST', z),
  // Alerts
  getAlerts: () => call(m.alerts, '/alerts'),
  acknowledgeAlert: (id) => call({ ok: true }, `/alerts/${id}/acknowledge`, 'PUT'),
  resolveAlert: (id) => call({ ok: true }, `/alerts/${id}/resolve`, 'PUT'),
  // Analytics / reports / settings
  getAnalytics: (range) => call(m.analytics, `/analytics?range=${range}`),
  generateReport: (type, format) => call({ ok: true, message: `${type} (${format}) requested` }, '/reports', 'POST', { type, format }),
  saveSettings: (s) => call({ ok: true }, '/settings', 'PUT', s),
  // AI Safety Assistant: backend returns { insights?: string[], reply?: string }
  askAssistant: (question) => call({ insights: m.insights, reply: 'Zone C is the highest-risk zone right now (160%). Consider sending staff to redirect people toward Zone A, which is at 25%.' }, '/ai-assistant', 'POST', { question }),
};
