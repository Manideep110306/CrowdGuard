import { useEffect, useRef, useState } from 'react';
import { api } from '../services/api';
import { Badge, Card, Feed, level, withOcc } from '../components/ui';

export default function Live() {
  const [cams, setCams] = useState([]);
  const [cam, setCam] = useState('cam1');
  const [zones, setZones] = useState([]);
  const [st, setSt] = useState(null);
  const [paused, setPaused] = useState(false);
  const box = useRef(null);

  useEffect(() => { api.getCameras().then(setCams); }, []);
  const load = async () => {
    if (paused) return;
    const [z, s] = await Promise.all([api.getZones(cam), api.getMonitoringStatus()]);
    setZones(z.map(withOcc)); setSt(s);
  };
  useEffect(() => { load(); const t = setInterval(load, 2000); return () => clearInterval(t); }, [cam, paused]);

  const start = async () => { await api.startMonitoring(cam); setPaused(false); load(); };
  const stop = async () => { await api.stopMonitoring(); setSt((s) => ({ ...s, running: false })); };
  const worst = zones.some((z) => level(z) === 'CRITICAL') ? 'CRITICAL' : zones.some((z) => level(z) === 'WARNING') ? 'WARNING' : 'NORMAL';
  const camName = cams.find((c) => c.id === cam)?.name || '';

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <h1 className="text-xl font-semibold mr-auto">Live Monitoring</h1>
        <select className="inp" style={{ width: 240 }} value={cam} onChange={(e) => setCam(e.target.value)}>
          <option disabled>Select Camera</option>
          {cams.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <button className="btn btn-p" onClick={start}>▶ Start Monitoring</button>
        <button className="btn btn-d" onClick={stop}>■ Stop Monitoring</button>
        <button className="btn" onClick={() => setPaused(!paused)}>{paused ? 'Resume' : '❚❚ Pause'}</button>
        <button className="btn" onClick={() => box.current?.requestFullscreen?.()}>⛶ Fullscreen</button>
      </div>

      <div className="grid xl:grid-cols-4 gap-4">
        <div className="xl:col-span-3" ref={box}><Feed zones={zones} name={camName} paused={paused} running={st?.running} /></div>
        <Card title="Real-time Monitoring">
          <dl className="text-sm space-y-3">
            {[['Camera', camName], ['Connection', <Badge s={st?.running ? 'ONLINE' : 'OFFLINE'} />], ['FPS', st?.running ? st.fps : '—'], ['Total people', zones.reduce((n, z) => n + z.people_count, 0)], ['Alert state', <Badge s={worst} />]].map(([k, v]) => (
              <div key={k} className="flex justify-between items-center"><dt className="text-slate-400">{k}</dt><dd className="font-medium">{v}</dd></div>
            ))}
          </dl>
        </Card>
      </div>

      <Card title="Zone Status">
        <table className="tbl">
          <thead><tr><th>Zone</th><th>People</th><th>Capacity</th><th>Occupancy</th><th>Status</th></tr></thead>
          <tbody>{zones.map((z) => (<tr key={z.id}><td><b>{z.name}</b></td><td>{z.people_count}</td><td>{z.capacity}</td><td>{z.occupancy}%</td><td><Badge s={level(z)} /></td></tr>))}</tbody>
        </table>
      </Card>
    </div>
  );
}
