import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Badge, Card } from '../components/ui';

const FILTERS = ['All', 'Warning', 'Critical', 'Active', 'Resolved'];

export default function Alerts() {
  const [alerts, setAlerts] = useState([]);
  const [f, setF] = useState('All');
  const [sel, setSel] = useState(null);
  const load = () => api.getAlerts().then((a) => { setAlerts(a); setSel((s) => (s ? a.find((x) => x.id === s.id) : null)); });
  useEffect(() => { load(); }, []);

  const shown = alerts.filter((a) => f === 'All' || a.severity === f.toUpperCase() || a.status === f.toUpperCase());
  const act = async (fn, id) => { await fn(id); load(); };

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Alerts</h1>
      <div className="flex gap-2 flex-wrap">{FILTERS.map((x) => <button key={x} className={`btn ${f === x ? 'btn-p' : ''}`} onClick={() => setF(x)}>{x}</button>)}</div>
      <div className="grid xl:grid-cols-3 gap-4">
        <Card className="xl:col-span-2"><div className="overflow-x-auto"><table className="tbl">
          <thead><tr><th>ID</th><th>Severity</th><th>Camera</th><th>Zone</th><th>People</th><th>Cap.</th><th>Occ.</th><th>Created</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>{shown.map((a) => (
            <tr key={a.id} className={sel?.id === a.id ? 'bg-cyan-500/5' : ''}>
              <td>{a.id}</td><td><Badge s={a.severity} /></td><td>{a.camera}</td><td>{a.zone}</td><td>{a.people_count}</td><td>{a.capacity}</td><td>{a.occupancy}%</td><td>{a.created_at}</td><td><Badge s={a.status} /></td>
              <td><div className="flex gap-1">
                <button className="btn" onClick={() => setSel(a)}>View Details</button>
                {a.status === 'ACTIVE' && <button className="btn" onClick={() => act(api.acknowledgeAlert, a.id)}>Acknowledge</button>}
                {a.status !== 'RESOLVED' && <button className="btn btn-p" onClick={() => act(api.resolveAlert, a.id)}>Resolve</button>}
              </div></td>
            </tr>))}</tbody>
        </table></div></Card>

        <Card title="Alert Details">
          {!sel ? <p className="text-sm text-slate-400">Select an alert to view details.</p> : (
            <div className="text-sm space-y-2">
              <div className="flex gap-2"><Badge s={sel.severity} /><Badge s={sel.status} /></div>
              <p><b>What:</b> {sel.zone} reached {sel.occupancy}% occupancy ({sel.severity.toLowerCase()} threshold exceeded).</p>
              <p><b>Where:</b> {sel.camera} · {sel.zone}</p>
              <p><b>When:</b> {sel.created_at}</p>
              <p><b>Current occupancy:</b> {sel.people_count} people ({sel.occupancy}%)</p>
              <p><b>Configured capacity:</b> {sel.capacity}</p>
              <div className="lbl pt-2">Alert history</div>
              <ul className="space-y-1 text-slate-300">{sel.history.map((h, i) => <li key={i} className="border-l-2 border-cyan-500/40 pl-2">{h}</li>)}</ul>
            </div>)}
        </Card>
      </div>
    </div>
  );
}
