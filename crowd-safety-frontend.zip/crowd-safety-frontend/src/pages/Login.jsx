import { useState } from 'react';
import { api } from '../services/api';

export default function Login({ onLogin }) {
  const [f, setF] = useState({ username: '', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true); setErr('');
    try { const r = await api.login(f); localStorage.setItem('token', r.token); localStorage.setItem('user', JSON.stringify(r.user)); onLogin(r.user); }
    catch (e) { setErr(e.message); }
    setBusy(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <svg className="absolute inset-0 w-full h-full opacity-30" viewBox="0 0 800 450" preserveAspectRatio="xMidYMid slice">
        {[[80, 90], [210, 300], [330, 140], [520, 330], [620, 120], [720, 260], [450, 200]].map(([x, y], i) => (
          <g key={i}><rect x={x} y={y} width="36" height="60" fill="none" stroke="#22d3ee" strokeWidth="1.2" /><text x={x} y={y - 4} fill="#22d3ee" fontSize="9">ID {i + 1}</text></g>
        ))}
        <rect x="20" y="20" width="760" height="410" fill="none" stroke="#22d3ee" strokeDasharray="8 6" />
      </svg>
      <div className="card p-8 w-full max-w-sm relative z-10">
        <div className="text-center mb-6">
          <div className="text-cyan-300 text-xs tracking-[.3em]">◉ SECURITY OPERATIONS</div>
          <h1 className="text-2xl font-bold tracking-widest mt-2">AI CROWD SAFETY</h1>
          <p className="text-xs text-slate-400 mt-1">Intelligent Crowd Monitoring &amp; Safety Alert System</p>
        </div>
        <div className="space-y-3">
          <input className="inp" placeholder="Email / Username" value={f.username} onChange={(e) => setF({ ...f, username: e.target.value })} />
          <input className="inp" type="password" placeholder="Password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} onKeyDown={(e) => e.key === 'Enter' && submit()} />
          {err && <div className="text-red-400 text-sm">{err}</div>}
          <button className="btn btn-p w-full py-2" onClick={submit} disabled={busy}>{busy ? 'Authenticating…' : 'Secure Login'}</button>
        </div>
      </div>
    </div>
  );
}
