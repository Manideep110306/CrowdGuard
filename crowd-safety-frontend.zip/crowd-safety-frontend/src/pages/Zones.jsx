import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Card, Feed, withOcc } from '../components/ui';

export default function Zones() {
  const [cams, setCams] = useState([]);
  const [cam, setCam] = useState('cam1');
  const [zones, setZones] = useState([]);
  const [saved, setSaved] = useState(false);

  useEffect(() => { api.getCameras().then(setCams); }, []);
  useEffect(() => { api.getZones(cam).then(setZones); }, [cam]);

  const edit = (id, k, v) => { setSaved(false); setZones(zones.map((z) => (z.id === id ? { ...z, [k]: v } : z))); };
  const save = async () => { await Promise.all(zones.map(api.saveZone)); setSaved(true); };
  const num = (z, k) => <input className="inp" type="number" style={{ width: 90 }} value={z[k]} onChange={(e) => edit(z.id, k, Number(e.target.value))} />;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap justify-between items-center gap-2">
        <h1 className="text-xl font-semibold">Zone Configuration</h1>
        <select className="inp" style={{ width: 240 }} value={cam} onChange={(e) => setCam(e.target.value)}>{cams.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
      </div>
      <div className="grid xl:grid-cols-2 gap-4">
        <Card title="Camera Preview"><Feed zones={zones.map(withOcc)} /><p className="text-xs text-slate-400 mt-2">Horizontal zones for now. The zone document can later store a polygon <code>points</code> array for custom shapes.</p></Card>
        <Card title="Monitoring Zones">
          <table className="tbl">
            <thead><tr><th>Zone</th><th>Capacity</th><th>Warning %</th><th>Critical %</th><th>Enabled</th></tr></thead>
            <tbody>{zones.map((z) => (
              <tr key={z.id}>
                <td><input className="inp" style={{ width: 110 }} value={z.name} onChange={(e) => edit(z.id, 'name', e.target.value)} /></td>
                <td>{num(z, 'capacity')}</td><td>{num(z, 'warning_threshold')}</td><td>{num(z, 'critical_threshold')}</td>
                <td><input type="checkbox" checked={z.enabled} onChange={(e) => edit(z.id, 'enabled', e.target.checked)} /></td>
              </tr>))}</tbody>
          </table>
          <div className="flex items-center gap-3 mt-4"><button className="btn btn-p" onClick={save}>Save Zone Configuration</button>{saved && <span className="text-sm text-emerald-400">Saved</span>}</div>
        </Card>
      </div>
    </div>
  );
}
