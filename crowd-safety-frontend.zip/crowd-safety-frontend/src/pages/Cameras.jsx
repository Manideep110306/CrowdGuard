import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Badge, Card, Field } from '../components/ui';

const EMPTY = { name: '', source_type: 'Webcam', location: '', device_id: '0', video_path: '', rtsp_url: '', username: '', password: '', port: '554' };

export default function Cameras() {
  const [cams, setCams] = useState([]);
  const [form, setForm] = useState(null);
  const [msg, setMsg] = useState('');
  const load = () => api.getCameras().then(setCams);
  useEffect(() => { load(); }, []);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const payload = () => {
    const { source_type: t } = form;
    const source = t === 'Webcam' ? form.device_id : t === 'Video' ? form.video_path : form.rtsp_url;
    return { name: form.name, source_type: t, source, location: form.location, ...(t === 'CCTV' ? { username: form.username, password: form.password, port: form.port } : {}) };
  };
  const test = async () => { const r = await api.testCamera(payload()); setMsg(r.message); };
  const save = async () => { form.id ? await api.updateCamera(form.id, payload()) : await api.addCamera(payload()); setForm(null); setMsg(''); load(); };
  const edit = (c) => setForm({ ...EMPTY, ...c, device_id: c.source_type === 'Webcam' ? c.source : '0', video_path: c.source_type === 'Video' ? c.source : '', rtsp_url: c.source_type === 'CCTV' ? c.source : '' });
  const remove = async (c) => { if (confirm(`Delete ${c.name}?`)) { await api.deleteCamera(c.id); load(); } };
  const start = async (c) => { await api.startMonitoring(c.id); load(); };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-semibold">Camera Management</h1>
        <button className="btn btn-p" onClick={() => setForm(EMPTY)}>+ Add Camera</button>
      </div>
      <Card>
        <div className="overflow-x-auto"><table className="tbl">
          <thead><tr><th>Camera Name</th><th>Source Type</th><th>Location</th><th>Status</th><th>Last Active</th><th>Actions</th></tr></thead>
          <tbody>{cams.map((c) => (
            <tr key={c.id}><td><b>{c.name}</b></td><td>{c.source_type}</td><td>{c.location}</td><td><Badge s={c.status} /></td><td>{c.last_active}</td>
              <td><div className="flex gap-1 flex-wrap">
                <button className="btn" onClick={() => edit(c)}>Edit</button>
                <button className="btn" onClick={async () => alert((await api.testCamera(c)).message)}>Test Connection</button>
                <button className="btn btn-p" onClick={() => start(c)}>Start Monitoring</button>
                <button className="btn btn-d" onClick={() => remove(c)}>Delete</button>
              </div></td></tr>))}</tbody>
        </table></div>
      </Card>

      {form && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="card p-6 w-full max-w-md space-y-3">
            <h2 className="font-semibold">{form.id ? 'Edit Camera' : 'Add Camera'}</h2>
            <Field label="Camera Name"><input className="inp" value={form.name} onChange={set('name')} /></Field>
            <Field label="Source Type"><select className="inp" value={form.source_type} onChange={set('source_type')}><option>Webcam</option><option>Video</option><option value="CCTV">CCTV / RTSP</option></select></Field>
            <Field label="Location"><input className="inp" value={form.location} onChange={set('location')} /></Field>
            {form.source_type === 'Webcam' && <Field label="Device ID (e.g. 0)"><input className="inp" value={form.device_id} onChange={set('device_id')} /></Field>}
            {form.source_type === 'Video' && <Field label="Video file path"><input className="inp" value={form.video_path} onChange={set('video_path')} /></Field>}
            {form.source_type === 'CCTV' && (<>
              <Field label="RTSP URL"><input className="inp" value={form.rtsp_url} onChange={set('rtsp_url')} placeholder="rtsp://ip:554/stream" /></Field>
              <div className="grid grid-cols-3 gap-2">
                <Field label="Username"><input className="inp" value={form.username} onChange={set('username')} /></Field>
                <Field label="Password"><input className="inp" type="password" value={form.password} onChange={set('password')} /></Field>
                <Field label="Port"><input className="inp" value={form.port} onChange={set('port')} /></Field>
              </div></>)}
            {msg && <div className="text-sm text-emerald-400">{msg}</div>}
            <div className="flex justify-between pt-2">
              <button className="btn" onClick={test}>Connection Test</button>
              <div className="flex gap-2"><button className="btn" onClick={() => { setForm(null); setMsg(''); }}>Cancel</button><button className="btn btn-p" onClick={save}>Save Camera</button></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
