import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Badge, Card, Feed, Stat, level, withOcc } from '../components/ui';
import ZoneCards from '../components/ZoneCards';
import AlertList from '../components/AlertList';
import AIAssistant from '../components/AIAssistant';

const PIPE = ['Camera', 'YOLO Detection', 'Tracking', 'Zones', 'Crowd Count', 'Alert Engine', 'MongoDB', 'Dashboard', 'AI Assistant'];

export default function Dashboard({ go }) {
  const [zones, setZones] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [cams, setCams] = useState([]);
  const [st, setSt] = useState(null);

  const load = async () => {
    const [z, a, c, s] = await Promise.all([api.getZones(), api.getAlerts(), api.getCameras(), api.getMonitoringStatus()]);
    setZones(z.map(withOcc)); setAlerts(a); setCams(c); setSt(s);
  };
  useEffect(() => { load(); const t = setInterval(load, 3000); return () => clearInterval(t); }, []);

  const act = async (fn, id) => { await fn(id); load(); };
  const people = zones.reduce((n, z) => n + z.people_count, 0);
  const active = alerts.filter((a) => a.status === 'ACTIVE').length;
  const crit = zones.filter((z) => level(z) === 'CRITICAL').length;
  const ok = (v) => v === 'ONLINE' || v === 'CONNECTED';

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-xl font-semibold">AI Crowd Safety Command Center</h1>
        {st && (
          <div className="flex gap-4 text-sm">
            <span><span className="dot" style={{ background: ok(st.ai_engine) ? '#34d399' : '#ef4444' }} /> AI Engine {st.ai_engine === 'ONLINE' ? 'Online' : 'Offline'}</span>
            <span><span className="dot" style={{ background: st.running ? '#34d399' : '#64748b' }} /> Monitoring {st.running ? 'Active' : 'Stopped'}</span>
            <span><span className="dot" style={{ background: ok(st.database) ? '#34d399' : '#ef4444' }} /> Database {ok(st.database) ? 'Connected' : 'Disconnected'}</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
        <Stat label="Active Cameras" value={cams.filter((c) => c.status === 'ONLINE').length} sub="Online" />
        <Stat label="People Detected" value={people} sub="Currently monitored" />
        <Stat label="Active Alerts" value={active} sub="Requires attention" tone={active ? 'warn' : ''} />
        <Stat label="Critical Zones" value={crit} sub="Immediate attention" tone={crit ? 'crit' : ''} />
      </div>

      <div className="grid xl:grid-cols-3 gap-4">
        <Card className="xl:col-span-2" title="Live Monitoring Overview" right={<button className="btn" onClick={() => go('Live Monitoring')}>Open Live View</button>}>
          <Feed zones={zones} running={st?.running} />
        </Card>
        <AIAssistant />
      </div>

      <ZoneCards zones={zones} />

      <div className="grid xl:grid-cols-2 gap-4">
        <AlertList alerts={alerts.slice(0, 3)} onView={() => go('Alerts')} onAck={(id) => act(api.acknowledgeAlert, id)} onResolve={(id) => act(api.resolveAlert, id)} />
        <Card title="System Pipeline">
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            {PIPE.map((p, i) => (<span key={p} className="flex items-center gap-1.5"><span className="badge b-online" style={{ color: '#67e8f9', borderColor: 'rgba(34,211,238,.4)', background: 'rgba(34,211,238,.08)' }}>{p}</span>{i < PIPE.length - 1 && <span className="text-slate-500">→</span>}</span>))}
          </div>
          <p className="text-xs text-slate-400 mt-3">Frontend only displays results. Detection, tracking, zone assignment and alerts run in the Flask + YOLO + OpenCV engine; data is stored in MongoDB and reaches this UI through REST APIs.</p>
        </Card>
      </div>
    </div>
  );
}
