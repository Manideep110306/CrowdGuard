import { useState } from 'react';
import { api } from '../services/api';
import { Card } from '../components/ui';

const REPORTS = [
  ['Daily Crowd Monitoring Report', 'People counts, zone occupancy and alerts for the selected day.'],
  ['Weekly Crowd Monitoring Report', 'Seven-day trends, peak periods and recurring crowded zones.'],
  ['Camera Performance Report', 'Uptime, FPS and detection activity for each camera.'],
  ['Alert Summary Report', 'All warning and critical alerts with response status.'],
];

export default function Reports() {
  const [msg, setMsg] = useState('');
  const run = async (type, format) => { try { setMsg((await api.generateReport(type, format)).message); } catch (e) { setMsg(e.message); } };
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Reports</h1>
      {msg && <div className="text-sm text-cyan-300">{msg}</div>}
      <div className="grid md:grid-cols-2 gap-4">
        {REPORTS.map(([t, d]) => (
          <Card key={t}><h3 className="font-semibold">{t}</h3><p className="text-sm text-slate-400 mt-1 mb-4">{d}</p>
            <div className="flex gap-2"><button className="btn btn-p" onClick={() => run(t, 'generate')}>Generate Report</button><button className="btn" onClick={() => run(t, 'pdf')}>Download PDF</button><button className="btn" onClick={() => run(t, 'csv')}>Export CSV</button></div>
          </Card>))}
      </div>
    </div>
  );
}
