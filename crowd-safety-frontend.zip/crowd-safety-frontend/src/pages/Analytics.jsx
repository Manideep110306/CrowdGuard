import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Card, ChartBox, Stat } from '../components/ui';

const RANGES = ['Today', '7 Days', '30 Days', 'Custom Range'];
const PAL = ['#22d3ee', '#fb923c', '#ef4444', '#a78bfa'];

export default function Analytics() {
  const [range, setRange] = useState('Today');
  const [d, setD] = useState(null);
  useEffect(() => { api.getAnalytics(range).then(setD); }, [range]);
  if (!d) return <p className="text-slate-400">Loading analytics…</p>;
  const s = d.stats;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap justify-between gap-2">
        <h1 className="text-xl font-semibold">Analytics</h1>
        <div className="flex gap-2">{RANGES.map((r) => <button key={r} className={`btn ${range === r ? 'btn-p' : ''}`} onClick={() => setRange(r)}>{r}</button>)}</div>
      </div>
      <div className="grid grid-cols-2 xl:grid-cols-5 gap-3">
        <Stat label="Average Occupancy" value={s.average_occupancy} />
        <Stat label="Peak Occupancy" value={s.peak_occupancy} tone="warn" />
        <Stat label="Total Alerts" value={s.total_alerts} />
        <Stat label="Critical Alerts" value={s.critical_alerts} tone="crit" />
        <Stat label="Peak Monitoring Time" value={s.peak_time} />
      </div>
      <div className="grid xl:grid-cols-2 gap-4">
        <Card title="People Count Over Time"><ChartBox type="line" data={{ labels: d.labels, datasets: [{ label: 'People', data: d.people, borderColor: PAL[0], backgroundColor: 'rgba(34,211,238,.12)', fill: true, tension: 0.35 }] }} /></Card>
        <Card title="Zone Occupancy Over Time (%)"><ChartBox type="line" data={{ labels: d.labels, datasets: Object.entries(d.zone_occupancy).map(([k, v], i) => ({ label: k, data: v, borderColor: PAL[i], tension: 0.35 })) }} /></Card>
        <Card title="Alerts Over Time"><ChartBox type="bar" data={{ labels: d.labels, datasets: [{ label: 'Alerts', data: d.alerts, backgroundColor: 'rgba(251,146,60,.7)' }] }} /></Card>
        <Card title="Peak Crowd Periods"><ChartBox type="bar" data={{ labels: d.labels, datasets: [{ label: 'Peak people', data: d.people, backgroundColor: d.people.map((v) => (v === Math.max(...d.people) ? '#ef4444' : 'rgba(34,211,238,.5)')) }] }} /></Card>
        <Card title="Camera Activity (%)" className="xl:col-span-2"><ChartBox type="doughnut" height={240} data={{ labels: Object.keys(d.camera_activity), datasets: [{ data: Object.values(d.camera_activity), backgroundColor: PAL, borderColor: '#0d1424' }] }} /></Card>
      </div>
    </div>
  );
}
