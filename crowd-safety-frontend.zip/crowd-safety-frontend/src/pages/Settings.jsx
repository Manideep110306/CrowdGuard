import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Badge, Card, Field } from '../components/ui';

export default function Settings() {
  const [s, setS] = useState({ confidence: 0.5, tracking: true, person_detection: true, warning: 80, critical: 100, delay: 5, fps_limit: 30, auto_reconnect: true, theme: 'Dark', name: 'Admin Operator', email: 'admin@crowdsafety.local' });
  const [st, setSt] = useState(null);
  const [saved, setSaved] = useState(false);
  useEffect(() => { api.getMonitoringStatus().then(setSt); }, []);

  const set = (k, v) => { setSaved(false); setS({ ...s, [k]: v }); };
  const Toggle = ({ k, label }) => <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={s[k]} onChange={(e) => set(k, e.target.checked)} />{label}</label>;
  const Num = ({ k, label, step = 1 }) => <Field label={label}><input className="inp" type="number" step={step} value={s[k]} onChange={(e) => set(k, Number(e.target.value))} /></Field>;

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Settings</h1>
      <div className="grid xl:grid-cols-2 gap-4">
        <Card title="AI Configuration" className="space-y-3">
          <Field label={`Detection Confidence: ${s.confidence}`}><input type="range" min="0.1" max="0.95" step="0.05" value={s.confidence} onChange={(e) => set('confidence', Number(e.target.value))} className="w-full" /></Field>
          <Toggle k="tracking" label="Tracking Enabled" /><Toggle k="person_detection" label="Person Detection Enabled" />
        </Card>
        <Card title="Alert Configuration"><div className="grid grid-cols-3 gap-2"><Num k="warning" label="Warning Threshold %" /><Num k="critical" label="Critical Threshold %" /><Num k="delay" label="Alert Delay (s)" /></div></Card>
        <Card title="Camera Configuration"><div className="space-y-3"><Num k="fps_limit" label="Max Processing FPS" /><Toggle k="auto_reconnect" label="Auto-reconnect lost cameras" /></div></Card>
        <Card title="System Configuration">
          <dl className="text-sm space-y-2">{st && [['Database Status', st.database], ['AI Engine Status', st.ai_engine], ['Backend Status', st.backend]].map(([k, v]) => <div key={k} className="flex justify-between"><dt className="text-slate-400">{k}</dt><dd><Badge s={v} /></dd></div>)}</dl>
        </Card>
        <Card title="Admin Account" className="xl:col-span-2"><div className="grid md:grid-cols-3 gap-2">
          <Field label="Name"><input className="inp" value={s.name} onChange={(e) => set('name', e.target.value)} /></Field>
          <Field label="Email"><input className="inp" value={s.email} onChange={(e) => set('email', e.target.value)} /></Field>
          <Field label="New Password"><input className="inp" type="password" onChange={(e) => set('password', e.target.value)} /></Field>
        </div></Card>
      </div>
      <div className="flex items-center gap-3"><button className="btn btn-p" onClick={async () => { await api.saveSettings(s); setSaved(true); }}>Save Settings</button>{saved && <span className="text-sm text-emerald-400">Saved</span>}</div>
    </div>
  );
}
