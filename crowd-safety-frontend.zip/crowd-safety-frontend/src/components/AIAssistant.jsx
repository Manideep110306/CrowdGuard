import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Card } from './ui';

// All reasoning happens in Flask (POST /api/ai-assistant). This only displays the replies.
export default function AIAssistant() {
  const [insights, setInsights] = useState([]);
  const [replies, setReplies] = useState([]);
  const [q, setQ] = useState('');

  useEffect(() => { api.askAssistant('summary').then((r) => setInsights(r.insights || [])); }, []);

  const ask = async () => {
    if (!q.trim()) return;
    const question = q; setQ('');
    const r = await api.askAssistant(question);
    setReplies((p) => [...p, { question, reply: r.reply }]);
  };

  return (
    <Card title="AI Safety Assistant" right={<span className="badge b-online">ANALYZING</span>}>
      <div className="space-y-2">
        {insights.map((t, i) => (
          <div key={i} className="text-sm border-l-2 pl-3 py-1" style={{ borderColor: i === 0 ? '#ef4444' : '#22d3ee' }}>{t}</div>
        ))}
        {replies.map((r, i) => (
          <div key={i} className="text-sm bg-slate-900/60 rounded-lg p-2">
            <div className="text-slate-400 text-xs">You: {r.question}</div><div>{r.reply}</div>
          </div>
        ))}
      </div>
      <div className="flex gap-2 mt-3">
        <input className="inp" placeholder="Ask about zones, cameras or alerts…" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && ask()} />
        <button className="btn btn-p" onClick={ask}>Ask</button>
      </div>
    </Card>
  );
}
