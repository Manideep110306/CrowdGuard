import { Badge, level } from './ui';

export default function ZoneCards({ zones }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
      {zones.map((z) => {
        const s = level(z);
        return (
          <div key={z.id} className={`card p-4 ${s === 'CRITICAL' ? 'card-crit' : ''}`}>
            <div className="flex justify-between items-center"><b>{z.name}</b><Badge s={s} /></div>
            <div className="text-2xl font-semibold mt-2">{z.people_count} <span className="text-sm text-slate-400">/ {z.capacity} people</span></div>
            <div className="h-1.5 bg-slate-800 rounded mt-2"><div className="h-full rounded" style={{ width: `${Math.min(z.occupancy, 100)}%`, background: s === 'CRITICAL' ? '#ef4444' : s === 'WARNING' ? '#fb923c' : '#22d3ee' }} /></div>
            <div className="text-xs text-slate-400 mt-1">{z.occupancy}% occupancy</div>
          </div>
        );
      })}
    </div>
  );
}
