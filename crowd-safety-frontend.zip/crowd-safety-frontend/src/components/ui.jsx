import { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';
import { STREAM_URL } from '../services/api';

export const COLORS = { NORMAL: '#34d399', WARNING: '#fb923c', CRITICAL: '#ef4444' };
export const withOcc = (z) => ({ ...z, occupancy: Math.round((z.people_count / z.capacity) * 100) });
export const level = (z) => (z.occupancy >= z.critical_threshold ? 'CRITICAL' : z.occupancy >= z.warning_threshold ? 'WARNING' : 'NORMAL');

export const Badge = ({ s }) => <span className={`badge b-${String(s).toLowerCase()}`}>{s}</span>;

export const Card = ({ title, right, children, className = '' }) => (
  <div className={`card p-4 ${className}`}>
    {(title || right) && (
      <div className="flex items-center justify-between mb-3">
        <h3 className="lbl">{title}</h3>
        <div className="flex gap-2">{right}</div>
      </div>
    )}
    {children}
  </div>
);

export const Stat = ({ label, value, sub, tone }) => (
  <div className={`card p-4 ${tone === 'crit' ? 'card-crit' : ''}`}>
    <div className="lbl">{label}</div>
    <div className={`text-3xl font-semibold mt-1 ${tone === 'crit' ? 'text-red-400' : tone === 'warn' ? 'text-orange-400' : 'text-cyan-300'}`}>{value}</div>
    <div className="text-xs text-slate-400 mt-1">{sub}</div>
  </div>
);

// Simulated feed: swap for the real Flask MJPEG stream by setting VITE_STREAM_URL
export function Feed({ zones = [], name = 'Webcam - Testing Camera', paused = false, running = true }) {
  const W = 800, H = 450, bh = H / Math.max(zones.length, 1);
  return (
    <div className="relative rounded-lg overflow-hidden border" style={{ borderColor: 'var(--line)', background: '#050810', aspectRatio: '16/9' }}>
      {STREAM_URL ? (
        <img src={STREAM_URL} alt="Live stream" className="absolute inset-0 w-full h-full object-cover" />
      ) : (
        <svg viewBox={`0 0 ${W} ${H}`} className="absolute inset-0 w-full h-full">
          <defs><pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M40 0H0V40" fill="none" stroke="#12203a" strokeWidth="1" /></pattern></defs>
          <rect width={W} height={H} fill="url(#grid)" />
          {zones.map((z, i) => {
            const c = COLORS[level(z)];
            return (
              <g key={z.id}>
                <rect x="3" y={i * bh + 3} width={W - 6} height={bh - 6} fill={c} fillOpacity=".05" stroke={c} strokeDasharray="6 4" />
                <text x="14" y={i * bh + 22} fill={c} fontSize="13" fontWeight="700">
                  {z.name} · People: {z.people_count} · Occupancy: {z.occupancy}%{level(z) === 'CRITICAL' ? ' · CRITICAL' : ''}
                </text>
                {Array.from({ length: Math.min(z.people_count, 16) }).map((_, k) => {
                  const x = 30 + (k % 8) * 92 + ((k * 13) % 17), y = i * bh + 38 + Math.floor(k / 8) * 52;
                  return (
                    <g key={k}>
                      <rect x={x} y={y} width="32" height="42" fill="none" stroke={c} strokeWidth="1.5" />
                      <text x={x} y={y - 3} fill={c} fontSize="9">ID {i * 20 + k + 1}</text>
                    </g>
                  );
                })}
              </g>
            );
          })}
        </svg>
      )}
      <div className="absolute top-2 left-3 flex items-center gap-2 text-xs">
        <span className={`dot ${running && !paused ? 'live' : ''}`} style={{ background: running && !paused ? '#ef4444' : '#64748b' }} />
        <b>{!running ? 'STOPPED' : paused ? 'PAUSED' : 'LIVE'}</b>
        <span className="text-slate-300">{name}</span>
      </div>
      <div className="absolute bottom-2 right-3 text-[11px] text-cyan-300/80">YOLO detection · Tracking ON · No face recognition</div>
    </div>
  );
}

// Thin Chart.js wrapper: pass type + data + options exactly as in the Chart.js docs
export function ChartBox({ type, data, options = {}, height = 220 }) {
  const ref = useRef(null);
  useEffect(() => {
    const chart = new Chart(ref.current, {
      type, data,
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { labels: { color: '#8394b0', boxWidth: 12 } } },
        scales: type === 'doughnut' ? {} : { x: { ticks: { color: '#8394b0' }, grid: { color: '#12203a' } }, y: { ticks: { color: '#8394b0' }, grid: { color: '#12203a' } } },
        ...options,
      },
    });
    return () => chart.destroy();
  }, [type, JSON.stringify(data)]);
  return <div style={{ height }}><canvas ref={ref} /></div>;
}

export const Field = ({ label, children }) => (
  <label className="block"><span className="lbl block mb-1">{label}</span>{children}</label>
);
