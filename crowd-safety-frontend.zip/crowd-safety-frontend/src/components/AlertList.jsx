import { Badge, Card } from './ui';

export default function AlertList({ alerts, onView, onAck, onResolve }) {
  return (
    <Card title="Recent Alerts">
      <div className="space-y-2">
        {alerts.map((a) => (
          <div key={a.id} className={`rounded-lg border p-3 ${a.severity === 'CRITICAL' && a.status === 'ACTIVE' ? 'border-red-500/50 bg-red-500/5' : 'border-slate-800'}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2"><Badge s={a.severity} /><b className="text-sm">{a.zone}</b><span className="text-sm">{a.occupancy}% occupancy</span></div>
              <Badge s={a.status} />
            </div>
            <div className="text-xs text-slate-400 mt-1">{a.id} · Camera: {a.camera} · {a.created_at}</div>
            <div className="flex gap-2 mt-2">
              <button className="btn" onClick={() => onView(a)}>View</button>
              {a.status === 'ACTIVE' && <button className="btn" onClick={() => onAck(a.id)}>Acknowledge</button>}
              {a.status !== 'RESOLVED' && <button className="btn btn-p" onClick={() => onResolve(a.id)}>Resolve</button>}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
