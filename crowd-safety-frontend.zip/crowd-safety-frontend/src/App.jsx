import { useEffect, useState } from 'react';
import { api } from './services/api';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Live from './pages/Live';
import Cameras from './pages/Cameras';
import Zones from './pages/Zones';
import Alerts from './pages/Alerts';
import Analytics from './pages/Analytics';
import Reports from './pages/Reports';
import Settings from './pages/Settings';

const NAV = [['Dashboard', '▦'], ['Live Monitoring', '◉'], ['Cameras', '▣'], ['Zones', '▤'], ['Alerts', '⚠'], ['Analytics', '▥'], ['Reports', '▧'], ['Settings', '⚙']];

export default function App() {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('user') || 'null'));
  const [page, setPage] = useState('Dashboard');
  const [now, setNow] = useState(new Date());
  const [st, setSt] = useState(null);
  const [open, setOpen] = useState(false);

  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);
  useEffect(() => { if (user) api.getMonitoringStatus().then(setSt); }, [user, page]);

  if (!user) return <Login onLogin={setUser} />;
  const logout = async () => { await api.logout(); localStorage.clear(); setUser(null); };
  const PAGES = { Dashboard: <Dashboard go={setPage} />, 'Live Monitoring': <Live />, Cameras: <Cameras />, Zones: <Zones />, Alerts: <Alerts />, Analytics: <Analytics />, Reports: <Reports />, Settings: <Settings /> };

  return (
    <div className="flex min-h-screen">
      <aside className="w-56 shrink-0 border-r flex flex-col p-3 sticky top-0 h-screen" style={{ borderColor: 'var(--line)', background: 'rgba(7,11,20,.92)' }}>
        <div className="px-2 py-3 mb-2"><div className="text-cyan-300 font-bold tracking-widest text-sm">◉ AI CROWD SAFETY</div><div className="text-[10px] text-slate-500 mt-0.5">Command Center</div></div>
        <nav className="space-y-1 flex-1">{NAV.map(([n, i]) => <button key={n} className={`nav ${page === n ? 'on' : ''}`} onClick={() => setPage(n)}><span>{i}</span>{n}</button>)}</nav>
        <div className="border-t pt-3" style={{ borderColor: 'var(--line)' }}>
          <div className="text-sm font-medium">{user.name}</div>
          <div className="text-xs text-emerald-400 mb-2"><span className="dot" style={{ background: '#34d399' }} /> Online</div>
          <button className="btn w-full" onClick={logout}>Logout</button>
        </div>
      </aside>

      <div className="flex-1 min-w-0">
        <header className="flex items-center justify-between px-6 py-3 border-b sticky top-0 z-20" style={{ borderColor: 'var(--line)', background: 'rgba(7,11,20,.85)', backdropFilter: 'blur(8px)' }}>
          <div className="text-sm text-slate-300">{now.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })} · <b>{now.toLocaleTimeString()}</b></div>
          <div className="flex items-center gap-5 text-sm">
            <span className="hidden md:inline"><span className="dot" style={{ background: st?.backend === 'ONLINE' ? '#34d399' : '#ef4444' }} /> System {st?.backend === 'ONLINE' ? 'Operational' : 'Check backend'}</span>
            <button className="relative text-lg" onClick={() => setPage('Alerts')} title="Alerts">🔔<span className="absolute -top-1 -right-2 bg-red-500 text-[10px] rounded-full px-1">2</span></button>
            <div className="flex items-center gap-2"><span className="w-7 h-7 rounded-full bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-xs">{user.name?.[0]}</span><span className="hidden md:inline">{user.name}</span></div>
          </div>
        </header>
        <main className="p-6">{PAGES[page]}</main>
      </div>
    </div>
  );
}
